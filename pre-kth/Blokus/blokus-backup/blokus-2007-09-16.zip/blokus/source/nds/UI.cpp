#include "UI.h"

#include <cstdio>

void UI::Init()
{
	printf("nds initialized! test to try makefiles\n");
}

void UI::Close()
{
	printf("nds out!\n");
}
