#include "SDL.h"

#include "Blokus.h"

int main(int argc, char *argv[])
{
	Blokus::Init();

	Blokus::Run();

	return 0;
}
