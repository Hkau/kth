#ifndef TILE_H
#define TILE_H

#include "Block.h"
#include "Types.h"

class Tile
{
	public:
		Tile(u8 width, u8 height/*, Block fill = BLOCK_EMPTY*/);

		inline u8 getWidth() {return Width;}

		inline u8 getHeight() {return Height;}

		inline Block getBlock(u8 x, u8 y)
		{
			return Blocks[y*Width + x];
		}
		
		inline void setBlock(Block block, u8 x, u8 y)
		{
			Blocks[y*Width + x] = block;
		}

	private:
		u8 Width, Height;

		Block* Blocks;
};

#endif

