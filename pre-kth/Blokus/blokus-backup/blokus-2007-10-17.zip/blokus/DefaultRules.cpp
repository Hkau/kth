#include "DefaultRules.h"

bool DefaultRules::ValidPlaceTile(Field&, Tile&)
{
	return true;
}

