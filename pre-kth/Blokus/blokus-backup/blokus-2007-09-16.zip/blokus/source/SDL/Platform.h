#ifndef PLATFORM_H
#define PLATFORM_H

class Platform
{
	public:
		static bool Init();

		static void HandleEvents();

		static void Exit();
};

#endif
