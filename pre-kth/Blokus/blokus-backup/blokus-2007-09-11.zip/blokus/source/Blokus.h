#ifndef BLOKUS_H
#define BLOKUS_H

class Blokus
{
	public:
		static bool Init();

		static void Run();

		static bool Shutdown();
	private:
		static bool bShutdown;
};

#endif
