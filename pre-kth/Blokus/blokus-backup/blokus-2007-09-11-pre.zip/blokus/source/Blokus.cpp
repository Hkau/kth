#include "Blokus.h"

#include "UI.h"

int blokusMain(int argc, char *argv[])
{
	UI::Init();

	UI::Close();

	return 0;
}
