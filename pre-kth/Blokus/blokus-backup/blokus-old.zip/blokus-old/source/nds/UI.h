#ifndef UI_header
#define UI_header

class UI
{
	public:
		static void Init();
		
		static void Close();
};

#endif
