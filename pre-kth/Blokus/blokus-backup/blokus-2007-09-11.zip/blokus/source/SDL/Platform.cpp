#include "Platform.h"
#include "Blokus.h"

#include "SDL.h"
#include "GL/Renderer.h"

bool Platform::Init()
{
	if(SDL_Init(SDL_INIT_VIDEO) == -1)
	{
		printf("Unable to initialize SDL\n");

		return false;
	}

	if(!SDL_SetVideoMode(640, 480, 32, SDL_OPENGL))
	{
		printf("Could not set video mode, shutting down... ");

		Exit();

		return false;
	}

	printf("SDL initialized! OMG\n");

	if(!Renderer::Init())
	{
		printf("Unable to initialize renderer, lol\n");

		return false;
	}

	if(!Renderer::SetMode(640, 480))
	{
		printf("Unable to initialize renderer, lol\n");

		return false;
	}

	return true;
}

void Platform::HandleEvents()
{
	static SDL_Event event;

	while(SDL_PollEvent(&event))
	{
		switch(event.type)
		{
			case SDL_KEYDOWN:
				if(event.key.keysym.sym == SDLK_ESCAPE)
					Blokus::Shutdown();
				break;

			case SDL_QUIT:
				Blokus::Shutdown();
				break;

			default:
				break;
		}
	}

	Renderer::RenderScene();

	SDL_GL_SwapBuffers();
}

void Platform::Exit()
{
	printf("SDL shutdown, for the lulz\n");
	SDL_Quit();
}
