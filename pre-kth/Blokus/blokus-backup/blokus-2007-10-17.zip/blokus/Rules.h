#ifndef RULES_H
#define RULES_H

#include "Field.h"
#include "Types.h"
#include "Player.h"

class Rules
{
	public:
		inline Field *CreateField() {return new Field(FieldWidth, FieldHeight);}

		inline Player *CreatePlayers()
		{
			Player *players = new Player[PlayerCount];
			
			for(u8 i = 1; i < PlayerCount; ++i)
			{
				players[i].setTeam(i+1);
			}
		}
		
		inline u8 getPlayerCount() { return PlayerCount; }

		virtual bool ValidPlaceTile(Field &field, Tile &tile) = 0;

	protected:

		u8 FieldWidth, FieldHeight;

		u8 PlayerCount;
};

#endif

