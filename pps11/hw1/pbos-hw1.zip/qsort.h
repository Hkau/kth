#include <stddef.h>

// qsort taken (stdlib.h)
void quicksort(int *array, size_t n);

