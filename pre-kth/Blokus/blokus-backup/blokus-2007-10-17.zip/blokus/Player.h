#ifndef PLAYER_H
#define PLAYER_H

#include "Types.h"

class Player
{
	public:
		Player(){ setTeam(1); Name="SpelarN^"; }
		Player(u8 team) { setTeam(team); Name = "SpelarN^"; }

		inline void setTeam(u8 team) { Team = team; }
		//name
		//score

	protected:
		u8 Team;
		char* Name;
};

#endif
