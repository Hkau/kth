extern int blokusMain(int argc, char *argv[]);
