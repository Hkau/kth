#include "Blokus.h"

#include "Platform.h"

// Static Blokus Variables
bool Blokus::bShutdown;

bool Blokus::Init()
{
	bShutdown = false;

	return Platform::Init();
}

void Blokus::Run()
{
	while(!bShutdown)
	{
		Platform::HandleEvents();
	}

	Platform::Exit();
}

bool Blokus::Shutdown()
{
	bShutdown = true;

	return true;
}
