#include "Game.h"

Game::Game(Rules *rules)
{
	GameRules = rules;
	
	GameField = GameRules->CreateField();
}

Game::~Game()
{
	delete GameField;
}

