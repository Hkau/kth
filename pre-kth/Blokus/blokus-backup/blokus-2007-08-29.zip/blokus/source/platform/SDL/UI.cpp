#include "UI.h"

#include <cstdio>

void UI::Init()
{
	printf("SDL initialized! test to try makefiles\n");
}

void UI::Close()
{
	printf("SDL out!\n");
}
