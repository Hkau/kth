#ifndef RULES_H
#define RULES_H

#include "Field.h"
#include "Types.h"

class Rules
{
	public:
		Rules() {FieldWidth = 20; FieldHeight = 20;} // temp, should not be defaultzed
		
		Field *CreateField() {return new Field(FieldWidth, FieldHeight);}
	
	private:
		
		u8 FieldWidth, FieldHeight;
};

#endif

