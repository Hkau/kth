#ifndef BLOKUS_H
#define BLOKUS_H

//TEMP LULZ//
#include "Field.h"
//TEMP LULZ//
extern Field *lolTempField;
//END TEMPZ//

class Blokus
{
	public:
		static bool Init();

		static void Run();

		static bool Shutdown();
	private:
		//Possibly temp.
		static bool bShutdown;
};

#endif
