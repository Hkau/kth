#include "Blokus.h"
#include <cstdio>

void printTile(Tile &tile)
{
	for(unsigned int i = 0; i < tile.getWidth(); ++i)
	{
		printf("|");
		for(unsigned int j = 0; j < tile.getHeight(); ++j)
		{
			printf("%d|", tile.getBlock(j, i).getValue());
		}
		printf("\n");
	}
}

int main()
{
	//Initialize game zomg default rules zomg (temp)

	Rules gameRules;
	Game game(&gameRules);
	
	Field *field = game.getField();
	
	printTile(*field);

	printf("Tile---\n");
	Tile omgTile(3,3);
	omgTile.setBlock(Block(3),0,0);
	omgTile.setBlock(Block(3),0,1);
	omgTile.setBlock(Block(3),1,1);
	omgTile.setBlock(Block(3),1,2);
	omgTile.setBlock(Block(3),2,2);
	printTile(omgTile);
	
	printf("Add tile to (3,3) <3---\n");

	game.PlaceTile(omgTile, 3, 3);

	printTile(*field);
	
	return 0;
}

