#include "UI.h"

int main()
{
	UI::Init();

	UI::Close();
	
	return 0;
}
