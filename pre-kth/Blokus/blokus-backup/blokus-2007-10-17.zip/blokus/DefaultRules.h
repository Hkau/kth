#ifndef DEFAULTRULES_H
#define DEFAULTRULES_H

#include "Rules.h"

class DefaultRules: public Rules
{
	public:
		inline DefaultRules()
		{
			FieldWidth = 20;
			FieldHeight = 20;

			PlayerCount = 4;
		}
		
		bool ValidPlaceTile(Field&, Tile&);
};

#endif

