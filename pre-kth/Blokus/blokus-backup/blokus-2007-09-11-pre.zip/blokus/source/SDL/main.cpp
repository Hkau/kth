#include "SDL.h"

#include "../Blokus.h"

int main(int argc, char *argv[])
{
	return blokusMain(argc, argv);
}
