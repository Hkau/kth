#ifndef BLOCK_H
#define BLOCK_H

class Block
{
	public:
		inline Block(){}
		inline Block(u8 value){Value = value;}

		inline void setValue(u8 value){Value = value;}
		inline u8 getValue(){return Value;}

	protected:
		u8 Value;
};

#endif
