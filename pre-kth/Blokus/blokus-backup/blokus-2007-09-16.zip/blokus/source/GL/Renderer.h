#ifndef RENDERER_H
#define RENDERER_H

#include <GL/gl.h>

class Renderer
{
	public:
		static bool Init();

		static bool SetMode(GLsizei Width, GLsizei Height);

		static void RenderScene();
};

#endif
