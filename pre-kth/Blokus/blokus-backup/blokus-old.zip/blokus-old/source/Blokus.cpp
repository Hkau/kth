#include "Blokus.h"

#include "Platform.h"

//Just as temporary...
Field *lolTempField;

// Static Blokus Variables
bool Blokus::bShutdown;

bool Blokus::Init(u8 x, u8 y)
{
	bShutdown = false;

	if(!Platform::Init())
		return false;

	lolTempField = new Field(20,20);

	return true;
}

void Blokus::Run()
{
	while(!bShutdown)
	{
		Platform::HandleEvents();
	}

	Platform::Exit();
}

bool Blokus::Shutdown()
{
	bShutdown = true;

	return true;
}
