#ifndef GAME_H
#define GAME_H

#include "Rules.h"

class Game
{
	public:
		Game(Rules *rules);
		~Game();
		
		inline Field *getField() {return GameField;}

	private:
		Rules *GameRules;
		
		Field *GameField;
};

#endif

