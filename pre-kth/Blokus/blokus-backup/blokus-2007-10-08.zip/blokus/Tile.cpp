#include "Tile.h"

Tile::Tile(u8 width, u8 height)
{
	Width = width;

	Height = height;

	Blocks = new Block[Width*Height];

	//for (u16 i = 0; i < Width * Height; ++i)
		//Blocks[i].setValue(1);

	//printf("LOLGNESTA?");

	/*for(u16 i = 0; i < Height; ++i)
		FieldBlocks[i*Width].setValue(0xAA);*/
}
