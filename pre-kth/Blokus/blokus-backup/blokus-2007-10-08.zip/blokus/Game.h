#ifndef GAME_H
#define GAME_H

#include "Rules.h"
#include "Tile.h"

class Game
{
	public:
		Game(Rules *rules);
		~Game();
		
		inline Field *getField() {return GameField;}
		
		bool PlaceTile(Tile &tile, u8 x, u8 y);

	private:
		Rules *GameRules;
		
		Field *GameField;
};

#endif

