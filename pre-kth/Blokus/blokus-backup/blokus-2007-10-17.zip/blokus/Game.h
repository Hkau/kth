#ifndef GAME_H
#define GAME_H

#include "Rules.h"
#include "Tile.h"
#include "Player.h"

class Game
{
	public:
		Game(Rules *rules);
		~Game();

		bool PlaceTile(Tile &tile, u8 x, u8 y);

		inline Field *getField() {return GameField;}
		inline Rules *getRules() {return GameRules;}

		//PLAYERS ZOMG


	private:
		Rules *GameRules;

		Field *GameField;

		Player *Players;
};

#endif

