#include "SDL.h"

#include "Blokus.h"

int main(int argc, char *argv[])
{
	Blokus::Init(20, 20);

	Blokus::Run();

	return 0;
}
