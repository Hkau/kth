#include "Blokus.h"
#include <cstdio>

int main()
{
	//Initialize game zomg default rules zomg (temp)

	Rules gameRules;
	Game game(&gameRules);
	
	Field *field = game.getField();
	
	for(unsigned int i = 0; i < field->getWidth(); ++i)
	{
		for(unsigned int j = 0; j < field->getHeight(); ++j)
		{
			printf("%d", field->getBlock(i, j).getValue());
		}
		printf("\n");
	}
	
	return 0;
}

