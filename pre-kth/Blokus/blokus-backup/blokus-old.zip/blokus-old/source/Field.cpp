#include "Field.h"
#include <cstdio>
Field::Field(u8 width, u8 height)
{
	DefaultBlock.setValue(0xFF);

	Width = width;

	Height = height;

	FieldBlocks = new Block[Width*Height];

	for (u16 i = 0; i < Width * Height; ++i)
		FieldBlocks[i] = DefaultBlock;

	for(u16 i = 0; i < Height; ++i)
		FieldBlocks[i*Width].setValue(0xAA);

/*	#if sizeof(DefaultBlock) == 1
	#error lol
	#else
	#error fill fieldblocks with DefaultBlock;
	#endif*/
}

Field::~Field()
{
	delete[] FieldBlocks;
}
