#include "Game.h"

Game::Game(Rules *rules)
{
	GameRules = rules;

	GameField = GameRules->CreateField();
	
	Players = GameRules->CreatePlayers();
}

Game::~Game()
{
	delete GameField;
}

//#include <cstdio>

bool Game::PlaceTile(Tile &tile, u8 x, u8 y)
{
	if(GameRules->ValidPlaceTile(*GameField, tile))
	{
		u8 width = tile.getWidth(), height = tile.getHeight();

		for(u8 i = 0; i < width; ++i)
		{
			for(u8 j = 0; j < height; ++j)
			{
				//printf("Adding block %d to (%d,%d)\n", tile.getBlock(i, j).getValue(), i+x, j+y);
				GameField->setBlock(tile.getBlock(i, j), i+x, j+y);
			}
		}

		return true;
	}

	return false;
}
