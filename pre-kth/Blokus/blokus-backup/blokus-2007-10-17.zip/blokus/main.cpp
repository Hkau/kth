#include "Blokus.h"
#include <cstdio>

void printTile(Tile &tile)
{
	for(unsigned int i = 0; i < tile.getHeight(); ++i)
	{
		printf("|");
		for(unsigned int j = 0; j < tile.getWidth(); ++j)
		{
			printf("%d|", tile.getBlock(j, i).getValue());
		}
		printf("\n");
	}
}

int main()
{
	//Initialize game zomg default rules zomg (temp)

	DefaultRules gameRules;
	Game game(&gameRules);

	Field *field = game.getField();

	printTile(*field);

	printf("----Tile----\n");
	Tile omgTile(4,3);
	omgTile.setBlock(Block(1),0,0);
	omgTile.setBlock(Block(1),1,0);
	omgTile.setBlock(Block(0),2,0);
	omgTile.setBlock(Block(0),3,0);
	omgTile.setBlock(Block(0),0,1);
	omgTile.setBlock(Block(1),1,1);
	omgTile.setBlock(Block(1),2,1);
	omgTile.setBlock(Block(1),3,0);
	omgTile.setBlock(Block(0),0,2);
	omgTile.setBlock(Block(1),1,2);
	omgTile.setBlock(Block(1),2,2);

	printTile(omgTile);

	omgTile.Rotate180();
	printf("\n----rot180----\n");
	printTile(omgTile);

	omgTile.RotateLeft();
	printf("\n----rotLeft----\n");
	printTile(omgTile);

	omgTile.RotateRight();
	printf("\n----rotRight----\n");
	printTile(omgTile);

	omgTile.FlipH();
	printf("\n----flipH----\n");
	printTile(omgTile);

	omgTile.FlipV();
	printf("\n----flipV----\n");
	printTile(omgTile);

	printf("\n---Add tile to (3,3) <3---\n");
	game.PlaceTile(omgTile, 3, 3);
	printTile(*field);

	return 0;
}

