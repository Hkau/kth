#include "Renderer.h"

#include <GL/glu.h>

#include "Blokus.h"

bool Renderer::Init()
{
	glShadeModel(GL_SMOOTH);
	glClearColor(0.0f, 0.0f, 0.0f, 0.5f);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	return true;
}

void Renderer::RenderScene()
{
	//Temporary gl test code
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	// Clear Screen And Depth Buffer
	glLoadIdentity();									// Reset The Current Modelview Matrix
	for(unsigned short i = 0; i < lolTempField->getHeight(); ++i)
	{
		for(unsigned short j = 0; j < lolTempField->getWidth(); ++j)
		{
			glPushMatrix();
				glTranslatef(i,j,0);							// Move Left 1.5 Units And Into The Screen 6.0
				glColor3f(float(lolTempField->getBlock(i, j).getValue())/255.0, float(lolTempField->getBlock(i, j).getValue())/255.0, float(lolTempField->getBlock(i, j).getValue())/255.0);
				glBegin(GL_QUADS);									// Draw A Quad
					glVertex3f(-0.5f, 0.5f, 0.0f);					// Top Left
					glVertex3f( 0.5f, 0.5f, 0.0f);					// Top Right
					glVertex3f( 0.5f,-0.5f, 0.0f);					// Bottom Right
					glVertex3f(-0.5f,-0.5f, 0.0f);					// Bottom Left
				glEnd();											// Done Drawing The Quad
			glPopMatrix();
		}
	}
}

bool Renderer::SetMode(GLsizei Width, GLsizei Height)
{
	//Temporary gl test code
	glViewport(0,0,Width,Height);						// Reset The Current Viewport

	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix

	// Calculate The Aspect Ratio Of The Window

	gluOrtho2D(-6,26,-2,22);

	glMatrixMode(GL_MODELVIEW);							// Select The Modelview Matrix
	glLoadIdentity();									// Reset The Modelview Matrix

	return true;
}
