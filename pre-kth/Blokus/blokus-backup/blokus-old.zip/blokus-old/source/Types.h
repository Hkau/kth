//Type header, it's a hack really.

typedef	unsigned char	u8;
typedef	signed char		s8;

typedef	unsigned short	u16;
typedef	signed short	s16;

typedef	unsigned int	u32;
typedef	signed int		s32;
