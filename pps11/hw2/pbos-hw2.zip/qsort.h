#include <stddef.h>

// qsort name taken (stdlib.h)
void quicksort(int *array, size_t n);

