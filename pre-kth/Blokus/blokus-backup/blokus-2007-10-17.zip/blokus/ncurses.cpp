#include "Blokus.h"
#include <curses.h>
#include "StandardTiles.h"

#define	FIELD_X	2
#define	FIELD_Y	1

static int cursorX = 0;
static int cursorY = 0;

inline void printField(Field *field)
{
	for(unsigned int i = 0; i < field->getHeight(); ++i)
	{
		mvaddch(FIELD_Y+i, FIELD_X, '|');
		for(unsigned int j = 0; j < field->getWidth(); ++j)
		{
			//move(FIELD_Y+i, FIELD_X+j*2+1);
			if(field->getBlock(j, i).getValue() <= 9 && field->getBlock(j, i).getValue() != 0) //ncurses port knows how to print up to 9 teams
				addch('0'+field->getBlock(j, i).getValue());
			else
				addch(' ');

			addch('|');
		}
	}
}

void printTile(Tile *tile, u8 x, u8 y)
{
	for(unsigned int i = 0; i < tile->getHeight()-0; ++i) // Don't print edges which only contain BLOCK_CORNER and BLOCK_EMPTY
	{
		for(unsigned int j = 0; j < tile->getWidth()-0; ++j) // Don't print edges which only contain BLOCK_CORNER and BLOCK_EMPTY
		{
			u8 value = tile->getBlock(j, i).getValue();
			if(value != 0 && value <= 9) //ncurses port knows how to print up to 9 teams, should not occur, don't print 0, wraps to >9
				mvaddch(y+i, x+j, '0' + tile->getBlock(j, i).getValue());
			
		}
	}
}

int main()
{
	//Initialize ncurses
	initscr();
	
	//Enable special keyboard stuff, like KEY_UP/DOWN etc, in ncurses.
	keypad(stdscr, true);

	noecho();

	DefaultRules gameRules;
	Game game(&gameRules);
	
	printField(game.getField());

	StandardTile21 foo(1);
	printTile(&foo, 50, 2);
	//printTile(game.getField(), FIELD_X, FIELD_Y);

	//printw("Hello World !!!");
	refresh();
	while(1)
	{
		move(FIELD_Y+(cursorY),FIELD_X+1+2*(cursorX));
		int keyPress = getch();
		if(keyPress == 'q')
			break;
		switch(keyPress)
		{
			case KEY_UP:
				if(cursorY > 0)
					cursorY--;
					
				break;

			case KEY_DOWN:
				if(cursorY < game.getField()->getHeight()-1)
					cursorY++;

				break;

			case KEY_LEFT:
				if(cursorX > 0)
					cursorX--;

				break;

			case KEY_RIGHT:
				if(cursorX < game.getField()->getWidth()-1)
					cursorX++;

				break;

			default:
				break;
		}
		refresh();
	}
	endwin();

	return 0;
}

