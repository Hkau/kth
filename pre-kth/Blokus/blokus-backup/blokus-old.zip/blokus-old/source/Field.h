#ifndef FIELD_H
#define FIELD_H

#include "Types.h"
#include "Block.h"

class Field
{
	public:
		Field(u8 width, u8 height);
		~Field();

		inline void setDefaultBlock(Block block){DefaultBlock = block;}

		inline Block getDefaultBlock(){return DefaultBlock;}

		inline void setWidth(u8 width){Width = width;}
		inline void setHeight(u8 height){Height = height;}

		inline u8 getWidth(){return Width;}
		inline u8 getHeight(){return Height;}

		inline void setBlock(u8 x, u8 y, Block block){FieldBlocks[Width*y + x] = block;}
		inline Block getBlock(u8 x, u8 y){return FieldBlocks[Width*y + x];}

	protected:
		u8 Width, Height;

		Block *FieldBlocks;
		Block DefaultBlock;
};

#endif
