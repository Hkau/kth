#include "UI.h"
#include "SDL.h"

#include <cstdio>

void UI::Init()
{
    SDL_SetVideoMode(800, 600, 32, 0);
	printf("SDL initialized! test to try makefiles\n");
}

void UI::Close()
{
	SDL_Quit();
	printf("SDL out! o/\n");
}
