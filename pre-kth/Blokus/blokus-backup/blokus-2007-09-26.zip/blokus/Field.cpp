#include "Field.h"

Field::Field(u8 width, u8 height)
{
	Width = width;

	Height = height;

	Blocks = new Block[Width*Height];

	/*for (u16 i = 0; i < Width * Height; ++i)
		FieldBlocks[i] = DefaultBlock;*/

	/*for(u16 i = 0; i < Height; ++i)
		FieldBlocks[i*Width].setValue(0xAA);*/
}
